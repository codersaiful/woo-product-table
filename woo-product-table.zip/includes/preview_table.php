<?php
/**
 * Not Activated yet. Will activate this file asap
 * Still not linked from  plugin of any file
 * 
 * 
 * Template File for wpt-product-table type post
 */

