<?php
echo esc_html( $wpt_table_row_serial );
