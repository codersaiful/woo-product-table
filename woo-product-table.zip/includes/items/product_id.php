<?php
echo the_ID();