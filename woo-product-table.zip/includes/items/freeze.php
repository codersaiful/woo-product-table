<?php


do_action( 'wpto_freeze_column', $settings, $product, $keyword, $table_ID, $column_settings );