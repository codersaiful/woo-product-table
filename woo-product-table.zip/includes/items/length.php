<?php
echo esc_html( $data['length'] );