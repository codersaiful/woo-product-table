<?php
echo wp_kses_post( $data['width'] );
