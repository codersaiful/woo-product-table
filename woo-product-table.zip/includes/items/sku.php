<?php
echo wp_kses_post( $product->get_sku() );
