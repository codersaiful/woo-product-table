<input type='text' 
       class='message message_<?php echo esc_attr( $id ); ?>' 
       value='' 
       id='message_<?php echo esc_attr( $id ); ?>' 
       placeholder='<?php echo esc_attr( $config_value['type_your_message'] ); ?>'>     
