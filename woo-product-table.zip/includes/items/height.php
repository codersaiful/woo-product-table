<?php
echo esc_html( $data['height'] );