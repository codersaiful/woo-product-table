<?php
echo get_the_date();
