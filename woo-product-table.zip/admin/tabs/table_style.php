<?php
$wpt_style_file_selection_options = WPT_Product_Table::$style_form_options;

?>
<div class="section ultraaddons-panel">
    <?php do_action( 'wpo_pro_feature_message', 'pf_style_tab' ); ?>
</div>