<div class="section ultraaddons-panel">
    <?php do_action( 'wpo_pro_feature_message', 'pf_table_configuration' ); ?>
</div>

